
package za.ac.tut.entities;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class WorkersFacade extends AbstractFacade<Workers> implements WorkersFacadeLocal {

    @PersistenceContext(unitName = "WorkersEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public WorkersFacade() {
        super(Workers.class);
    }
    
}
