
package za.ac.tut.entities;

import java.util.List;
import javax.ejb.Local;

@Local
public interface WorkersFacadeLocal {

    void create(Workers workers);

    void edit(Workers workers);

    void remove(Workers workers);

    Workers find(Object id);

    List<Workers> findAll();

    List<Workers> findRange(int[] range);

    int count();
    
}
