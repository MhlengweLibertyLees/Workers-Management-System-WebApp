package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.entities.Workers;
import za.ac.tut.entities.WorkersFacadeLocal;

public class WorkersServlet extends HttpServlet {

    @EJB
    private WorkersFacadeLocal local;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("idNumber");
        Long idNumber = Long.parseLong(id);
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String email = request.getParameter("email");
        String gender = request.getParameter("gender");
        String jobTitle = request.getParameter("jobTitle");
        String date = request.getParameter("dateHired");
        Date dateHired = null;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-DD");
            dateHired = sdf.parse(date);
        } catch (Exception e) {
            e.getMessage();
        }

        boolean isValid = idNumber != null && !id.isEmpty()
                && firstName != null && !firstName.isEmpty()
                && lastName != null && !lastName.isEmpty()
                && email != null && !email.isEmpty()
                && gender != null && !gender.isEmpty()
                && jobTitle != null && !jobTitle.isEmpty()
                && dateHired != null && !date.isEmpty();

        if (isValid) {
            try {
                local.create(new Workers(idNumber, firstName, lastName, email, gender, jobTitle, dateHired));
                List<Workers> list = new ArrayList<>();

                if (local != null) {
                    request.setAttribute("message", "Successfully added worker to the database");
                } else {
                    
                    request.setAttribute("message", "Failed to add worker!");
                   

                }
                
            } 
            catch (NullPointerException e) {
                
                request.setAttribute("message", "Failed to add worker!");
                
            }
            catch (NumberFormatException e) {
                
                request.setAttribute("message", "Invalid id entered try again to add worker!");
                
            }
            catch (Exception e) {
                List<Workers> list = local.findAll();
                for (Workers work : list) {
                    if (work.getIdNumber().equals(idNumber)) {
                        request.setAttribute("message", "Id number already exists in the database!");
                    } else {
                        request.setAttribute("message", "Failed to add worker!");
                    }
                }
                
            }
        } else {

            request.setAttribute("message", "Failed to add worker!");

        }

        RequestDispatcher disp = request.getRequestDispatcher("add_worker_output.jsp");
        disp.forward(request, response);

    }

}
