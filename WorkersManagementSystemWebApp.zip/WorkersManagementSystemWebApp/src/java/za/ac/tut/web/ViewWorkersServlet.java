package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.entities.Workers;
import za.ac.tut.entities.WorkersFacadeLocal;

public class ViewWorkersServlet extends HttpServlet {

    @EJB
    private WorkersFacadeLocal local;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Workers workers = new Workers();
        
        List<Workers> list = local.findAll();
        request.setAttribute("list", list);
        
        RequestDispatcher disp = request.getRequestDispatcher("view_workers.jsp");
        disp.forward(request, response);
    }

}
