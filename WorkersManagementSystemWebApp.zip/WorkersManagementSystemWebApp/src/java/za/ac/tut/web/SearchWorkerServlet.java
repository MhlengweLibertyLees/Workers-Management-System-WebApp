package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.entities.Workers;
import za.ac.tut.entities.WorkersFacadeLocal;

public class SearchWorkerServlet extends HttpServlet {

    @EJB
    private WorkersFacadeLocal local;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("idNumber");
        Long idNumber = Long.parseLong(id);

        boolean isValid = !id.isEmpty() && idNumber != null;

        try {
            if (isValid) {

                Workers workers = local.find(idNumber);

                Long id2 = workers.getIdNumber();
                String firstName = workers.getFirstName();
                String lastName = workers.getLastName();
                String email = workers.getEmail();
                String gender = workers.getGender();
                String jobTitle = workers.getJobTitle();
                Date dateHired = workers.getDateHired();

                List<Workers> search = new ArrayList<>();

                if (local.find(idNumber) != null && workers != null) {
                    search.add(workers);
                    request.setAttribute("search", search);
                } else {
                    request.setAttribute("message", "Worker not found");
                }

            }

        } catch (Exception e) {
            request.setAttribute("message", "Worker not found");
        }
        RequestDispatcher disp = request.getRequestDispatcher("search_worker_outcome.jsp");
        disp.forward(request, response);
    }

}
