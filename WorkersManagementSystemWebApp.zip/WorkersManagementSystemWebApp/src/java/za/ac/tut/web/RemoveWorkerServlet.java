package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.entities.Workers;
import za.ac.tut.entities.WorkersFacadeLocal;

public class RemoveWorkerServlet extends HttpServlet {

    @EJB
    private WorkersFacadeLocal local;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("idNumber");
        Long idNumber = Long.parseLong(id);

        boolean isValid = !id.isEmpty() && idNumber != null;

        if (isValid) {
            Workers workers = local.find(idNumber);
            List<Workers> list = new ArrayList<>();

            Long id2 = workers.getIdNumber();
            String firstName = workers.getFirstName();
            String lastName = workers.getLastName();
            String email = workers.getEmail();
            String gender = workers.getGender();
            String jobTitle = workers.getJobTitle();
            Date dateHired = workers.getDateHired();

            try {
                local.remove(new Workers(idNumber, firstName, lastName, email, gender, jobTitle, dateHired));
                request.setAttribute("message", "Worker has been successfully removed!");
            } catch (Exception e) {
                request.setAttribute("message", "Failed! Worker is not available is the database.");
            }

        } else {
            request.setAttribute("message", "Failed! Worker is not available is the database.");
        }

        RequestDispatcher disp = request.getRequestDispatcher("remove_worker_outcome.jsp");
        disp.forward(request, response);

    }

}
