package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.entities.Workers;
import za.ac.tut.entities.WorkersFacadeLocal;

public class EditWorkerServlet extends HttpServlet {

    @EJB
    private WorkersFacadeLocal local;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("idNumber");
        Long idNumber = Long.parseLong(id);
        String newJobTitle = request.getParameter("newJobTitle");

        boolean isValid = !id.isEmpty() && idNumber != null
                && !newJobTitle.isEmpty() && newJobTitle != null;

        if (isValid) {
            try {
                Workers w = local.find(idNumber);

                w.setJobTitle(newJobTitle);
                local.edit(w);

                request.setAttribute("message", "Successfully changed the Job Title");
            } catch (Exception e) {
                request.setAttribute("message", "Failed to change Job Title");
            }
        } else {
            request.setAttribute("message", "Failed to change Job Title");
        }
        RequestDispatcher disp = request.getRequestDispatcher("edit_worker_outcome.jsp");
        disp.forward(request, response);
    }

}
